import version
import config
import enum
import utils
import json
import  re
import constant

__author__ = 'Matteo Marescotti'


class SolveStatus(enum.Enum):
    unknown = 0
    sat = 1
    unsat = -1

class Node:
    def __init__(self, parent, smt):
        if parent and not isinstance(parent, Node):
            raise TypeError('Node expected')
        self._parent = parent
        if self._parent is not None:
            self._parent._children.append(self)
            self._root = self._parent._root
        else:
            self._root = self
        self.smt = smt
        self._children = []
        self._status = SolveStatus.unknown
        self._start_time = None
        self.total_runtime = None
        self.counted = True

    def __repr__(self):
        path = self.path()
        return '<{}:{}>'.format(
            self.path(),
            self.status.name
        )

    def __hash__(self):
        return id(self)

    def __lt__(self, other):
        return len(self.path()) < len(other.path())

    def __eq__(self, other):
        return self is other

    def __ne__(self, other):
        return self is not other

    def __getitem__(self, key):
        return self._children[key]

    def __iter__(self):
        return self._children.__iter__()

    def __len__(self):
        return self._children.__len__()

    def path(self, nodes=False):
        node = self
        path = []
        while node.parent:
            path.append(node.parent if nodes else node.parent._children.index(node))
            node = node.parent
        path.reverse()
        return path

    def path_to_node(self):
        node = self
        path = [node]
        while node.parent:
            if isinstance(node.parent, AndNode):
                path.append(node.parent)
            node = node.parent
        path.reverse()
        return path

    def is_ancestor(self, node):
        if self.root != node.root:
            raise ValueError('provided node from a different tree')
        selfp = self.path()
        nodep = node.path()
        if len(selfp) > len(nodep):
            return False
        for i in range(len(selfp)):
            if selfp[i] != nodep[i]:
                return False
        return True

    def all_children(self):
        nodes = [self]
        for node in self:
            nodes += node.all_children()
        return nodes

    def all_and_children(self):
        pass

    def clear(self):
        self._children.clear()

    @property
    def parent(self):
        return self._parent

    @property
    def root(self):
        return self._root

    @property
    def level(self):
        return len(self.path())

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, status):
        self._set_status(status)

    def _set_status(self, status: SolveStatus):
        raise NotImplementedError

    @property
    def start_time(self):
        return self._start_time

    @start_time.setter
    def start_time(self, time):
        self._start_time = time
        self.total_runtime = 0

    def started(self):
        return self.start_time is not None

    def runtime(self):
        if not self.started():
            return 0
        return time.time() - self.start_time

    def n_timeouts(self):
        if not self.started():
            return 0
        assert config.node_timeout
        return self.total_runtime/config.node_timeout

class AndNode(Node):
    def __init__(self, parent, smt):
        if not isinstance(parent, (OrNode, type(None))):
            raise TypeError
        super().__init__(parent, smt)
        self._solved = False

    def _set_status(self, status: SolveStatus):
        self._status = status
        if self.parent:
            if status == SolveStatus.sat or all([node.status == status for node in self.parent]):
                self.parent.status = status

    def all_and_children(self):
        nodes = [self]
        for node in self:
            assert isinstance(node, OrNode)
            nodes += node.all_and_children()
        return nodes

    def remaining_and_children(self):
        childs = []
        for ch in (self._children[0])._children:
            if ch.status == SolveStatus.unknown:
                childs.append(ch)
        return childs

    @property
    def solved(self):
        return self._solved

    @solved.setter
    def solved(self, p):
        self._solved = p

class OrNode(Node):
    def __init__(self, parent, smt: str = ''):
        if not isinstance(parent, AndNode):
            raise TypeError
        super().__init__(parent, smt)

    def _set_status(self, status: SolveStatus):
        self._status = status
        assert self.parent
        if self.parent.status != status:
            self.parent.status = status

    def all_and_children(self):
        nodes = []
        for node in self:
            assert isinstance(node, AndNode)
            nodes += node.all_and_children()
        return nodes


class Root(AndNode):
    def __init__(self, name: str, smt: str):
        super().__init__(None, smt)
        self.name = name

    def __repr__(self):
        return '<{} "{}":{}>'.format(
            self.__class__.__name__,
            self.name,
            self.status.name
        )

    def child(self, path: list):
        node = self
        for i in path:
            node = node[int(i)]
        return node

    def to_string(self, node: AndNode, start: AndNode = None):
        raise NotImplementedError


class SMT(Root):
    def __init__(self, name: str, smt: str):
        super().__init__(name, smt)

    def to_string(self, node: AndNode, start: AndNode = None):
        n_pop = 0
        if start is not None:
            while not start.is_ancestor(node):
                if isinstance(start, AndNode):
                    n_pop += 1
                start = start.parent
        smt = []

        while node is not start:
            if isinstance(node, AndNode):
                smt.append(node.smt)
                if node != self.root:
                    smt.append('(push 1)')
            node = node.parent
        smt += ['(pop 1)' for _ in range(n_pop)]
        smt.reverse()
        return '\n'.join(smt), constant.CHECK_SAT


class Fixedpoint(Root):
    def __init__(self, name: str, smt: str):
        self.json = utils.smt2json(smt)
        self.query = None
        for i in self.json:
            if i[0] == constant.QUERY:
                self.query = i[1]
                self.json = self.json[:self.json.index(i)]
                break
        if self.query is None:
            raise ValueError('query not found')
        self.json = [i for i in self.json if i[0] != constant.QUERY]
        super().__init__(name, smt.split('(' + constant.QUERY)[0])

    def partition(self):
        obj = self.json.copy()
        queries = []
        for i in obj:
            try:
                if i[0] != 'rule':
                    continue
                i = i[1]
                while i[0] == 'let':
                    i = i[2]
                if i[0] == '=>' and i[2] == self.query:
                    queries.append('{}{}'.format(self.query, len(queries)))
                    i[2] = queries[-1]
            except:
                pass

        for i in range(len(obj)):
            if obj[i][0] == 'declare-rel':
                for query in queries:
                    obj.insert(i, ['declare-rel', query, []])
                break

        parent = OrNode(self, utils.json2smt(obj))
        if config.db():
            config.db().cursor().execute("INSERT INTO {}SolvingHistory (name, node, event, solver, data) "
                                         "VALUES (?,?,?,?,?)".format(config.table_prefix), (
                                             self.name,
                                             str(self.path()),
                                             'OR',
                                             '',
                                             json.dumps({'node': str(parent.path())})
                                         ))

        for query in queries:
            child = AndNode(parent, '(query ' + query + ')')
            if config.db():
                config.db().cursor().execute("INSERT INTO {}SolvingHistory (name, node, event, solver, data) "
                                             "VALUES (?,?,?,?,?)".format(config.table_prefix), (
                                                 self.name,
                                                 str(self.path()),
                                                 'AND',
                                                 '',
                                                 json.dumps({'node': str(child.path())})
                                             ))

        if config.db():
            config.db().commit()

    def to_string(self, node: AndNode, start: AndNode = None):
        self.is_ancestor(node)
        if start is not None:
            raise ValueError
        if node is self:
            return self.smt, '(query ' + self.query + ')'
        elif isinstance(node, AndNode):
            return node.parent.smt, node.smt


# class Fixedpoint(Root):
#     def __init__(self, name: str, fixedpoint, queries):
#         s = fixedpoint.to_string([])
#         self.query = str(queries[0].sexpr())
#         super().__init__(name, s[s.index('(declare-rel '):])
#
#     def partition(self, fixedpoint, queries):
#         if len(self) > 0:
#             raise ValueError('already partitioned')
#         _f = config.z3().Fixedpoint(ctx=fixedpoint.ctx)
#         query = queries[0]
#         queries = []
#         for rule in fixedpoint.get_rules():
#             if config.z3().is_quantifier(rule):
#                 imp = rule.body()
#                 body = imp.arg(0)
#                 if imp.num_args() == 2:  # if is implies
#                     head = imp.arg(1)
#                     if config.z3().is_and(body):
#                         for i in range(body.num_args()):  # app always before others
#                             ch = body.arg(i)
#                             if config.z3().is_app(ch) and ch.decl().kind() == config.z3().Z3_OP_UNINTERPRETED:
#                                 _f.register_relation(ch.decl())
#                             else:
#                                 break
#                     else:
#                         _f.register_relation(body.decl())
#                     if head.eq(query):
#                         head = config.z3().Bool(query.sexpr() + str(len(queries)), fixedpoint.ctx)
#                         queries.append(head)
#                     _f.register_relation(head.decl())
#                     _f.add_rule(head, body)
#                     continue
#             else:
#                 imp = rule
#             _f.register_relation(imp.decl())
#             _f.add_rule(rule)
#
#         s = _f.to_string([])
#         parent = OrNode(self, s[s.index('(declare-rel '):])
#         if config.db():
#             config.db().cursor().execute("INSERT INTO {}SolvingHistory (name, node, event, solver, data) "
#                                          "VALUES (?,?,?,?,?)".format(config.table_prefix), (
#                                              self.name,
#                                              str(self.path()),
#                                              'OR',
#                                              '',
#                                              json.dumps({'node': str(parent.path())})
#                                          ))
#
#         for query in queries:
#             child = AndNode(parent, '(query ' + query.sexpr() + ')')
#             if config.db():
#                 config.db().cursor().execute("INSERT INTO {}SolvingHistory (name, node, event, solver, data) "
#                                              "VALUES (?,?,?,?,?)".format(config.table_prefix), (
#                                                  self.name,
#                                                  str(self.path()),
#                                                  'AND',
#                                                  '',
#                                                  json.dumps({'node': str(child.path())})
#                                              ))
#
#         if config.db():
#             config.db().commit()
#
#     def to_string(self, node: AndNode, start: AndNode = None):
#         if node.root != self:
#             raise ValueError
#         if node is self:
#             return self.smt, '(query ' + self.query + ')'
#         elif isinstance(node, AndNode):
#             return node.parent.smt, node.smt


class MCMT(Root):
    def __init__(self, name: str, smt: str):
        super().__init__(name, smt)

    def to_string(self, node: AndNode, start: AndNode = None):
        return self.smt, ''


def parse(name: str, smt: str):
    if name.endswith(".mcmt"):
        return MCMT(name, smt)
    if smt.find('(query ') > 0:
        return Fixedpoint(name, smt)
    else:
        return SMT(name, smt)
